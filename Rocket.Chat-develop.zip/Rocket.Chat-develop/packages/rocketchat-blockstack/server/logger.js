import { Logger } from 'meteor/rocketchat:logger';

export const logger = new Logger('Blockstack');
