import './lib/actionButton';
import './lib/autotranslate';
import './lib/tabBar';
import './views/autoTranslateFlexTab.html';
import './views/autoTranslateFlexTab';
