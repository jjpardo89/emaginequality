import './template/admin.html';
import './template/result.html';
import './template/suggestion.html';
import './template/admin';
import './template/result';
import './template/suggestion';
import './route';
