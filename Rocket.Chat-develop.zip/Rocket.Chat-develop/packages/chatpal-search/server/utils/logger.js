import { Logger } from 'meteor/rocketchat:logger';

const ChatpalLogger = new Logger('Chatpal Logger', {});
export default ChatpalLogger;
